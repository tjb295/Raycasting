#ifndef _RAYCASTER_H
#define _RAYCASTER_H

#define PIXEL_COUNT 1024

typedef struct Pixel {
	unsigned char r,g,b;
} Pixel;


#endif /*_RAYCASTER_H */
